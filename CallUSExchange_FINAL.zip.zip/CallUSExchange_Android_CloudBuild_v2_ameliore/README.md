# CALL US EXCHANGE — prototype Android

## Fonctionnalités de démonstration
- Interface client avec HTG, USDT, DOP et BRL.
- Conversion indicative calculée à partir des taux configurés localement.
- Formulaires de demande d'échange et de recharge (NatCash, MonCash, MERÚ).
- Espace ADM local pour modifier les taux et consulter / mettre à jour le statut des demandes.
- Les données sont enregistrées dans le stockage local du navigateur WebView de l'appareil.

## Accès ADM de démonstration
Code initial : `2468`.
Ce code est intégré au prototype et ne constitue PAS une sécurité. Ne pas utiliser cette version pour gérer de l'argent réel ou des données sensibles.

## Limites importantes
- Aucun backend, compte utilisateur ou synchronisation entre appareils.
- Les demandes ne sont visibles que sur l'appareil où elles ont été créées.
- Les taux sont des exemples modifiables, pas des taux de marché en direct.
- NatCash, MonCash et MERÚ ne sont pas connectés ; aucun paiement ni transfert n'est effectué.
- Avant une mise en production, il faut une API/backend sécurisé, une authentification réelle, une base de données, des contrôles d'accès, une journalisation et les intégrations officielles de paiement, suivis d'un audit de sécurité.

## Générer l'APK avec GitHub Actions
1. Téléverser tout le contenu du projet dans un dépôt GitHub.
2. Conserver le dossier caché `.github/workflows/` et le fichier `android-apk.yml`.
3. Ouvrir l'onglet **Actions** puis lancer **Build Android APK**.
4. À la fin du workflow, télécharger l'artifact **Call-US-Exchange-APK**.
